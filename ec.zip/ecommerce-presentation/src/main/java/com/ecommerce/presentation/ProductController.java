package com.ecommerce.presentation;

import static org.assertj.core.api.Assertions.setAllowComparingPrivateFields;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import application.ProductManagerRemote;
import model.Product;

/**
 * Servlet implementation class ProductController
 */

@Controller
public class ProductController {
       
	private static final Logger logger = LoggerFactory.getLogger(ProductController.class);
	
	@Autowired
	private ProductManagerRemote productOP;
	
	@RequestMapping(value = "/product", method = RequestMethod.GET)
	public String catalogo(Locale locale, Model model) {
		
		return "catalogo";
	}
	
	@RequestMapping(value = "/productType", method = RequestMethod.GET)
	public String productView(HttpSession session,Locale locale, Model model, @RequestParam String tipo) {
		
		List<Product> lp=productOP.getProductList(tipo);
		model.addAttribute("lista", lp);
		session.setAttribute("lista", lp);
		logger.info("nome prodotto: "+lp.toString());
		return "catalogo";
	}
	
	@RequestMapping(value = "/addcart", method = RequestMethod.POST)
	public String addCart(HttpSession session, Model model,
			@RequestParam int idProduct, @RequestParam int quantita){
		ArrayList<Product> cart = (ArrayList<Product>) session.getAttribute("cart");
		if(cart == null)
		{
			cart = new ArrayList<Product>();
			Product product = productOP.findProduct(idProduct);
			cart.add(product);
			System.out.println("carrello creato");
		}
		else
		{
			Product product = productOP.findProduct(idProduct);
			cart.add(product);
			for(Product p:cart)
				System.out.println("TUA MADRE: "+p.getDescrizione()+" "+p.getPrezzo());
		}
		
		session.setAttribute("cart", cart);
		
		return "catalogo";
	}
	
	@RequestMapping(value = "/viewcart", method = RequestMethod.GET)
	public String viewcart(HttpSession session, Model model)
	{		
		ArrayList<Product> cart = (ArrayList<Product>) session.getAttribute("cart");
		model.addAttribute("cart", cart);
		session.setAttribute("cart", cart);
		//logger.info("cart: "+cart.toString());
		
		return "cartshop";
	}
	
	@RequestMapping(value = "/removeproductcart", method = RequestMethod.POST)
	public String removeproductcart(HttpSession session, Model model, @RequestParam int idProduct)
	{		
		ArrayList<Product> cart = (ArrayList<Product>) session.getAttribute("cart");
		if(!cart.isEmpty()) {
		for(Product p : cart)
		{
			if(p.getId()==idProduct)
				cart.remove(p);
		}
		session.setAttribute("cart", cart);
		logger.info("cart: "+cart.toString());
		}

				
		return "cartshop";
	}
	
}